This is a collection of helper scripts and functions for use in DETR's Research & Analysis Bureau in R.
